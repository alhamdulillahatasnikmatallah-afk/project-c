import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';

class DailyToolsScreen extends StatelessWidget {
  const DailyToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'HARIAN',
        child: ListView(children: [
          TermListTile(
              label: 'Kalkulator sederhana',
              icon: Icons.calculate,
              onTap: () => _go(context, const _CalcScreen())),
          TermListTile(
              label: 'Konverter satuan',
              icon: Icons.swap_horiz,
              onTap: () => _go(context, const _UnitScreen())),
          TermListTile(
              label: 'Timer & stopwatch',
              icon: Icons.timer,
              onTap: () => _go(context, const _TimerScreen())),
        ]),
      );
  void _go(BuildContext c, Widget p) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => p));
}

class _CalcScreen extends StatefulWidget {
  const _CalcScreen();
  @override
  State<_CalcScreen> createState() => _CalcScreenState();
}

class _CalcScreenState extends State<_CalcScreen> {
  final a = TextEditingController();
  final b = TextEditingController();
  String out = '';

  void _calc(String op) {
    Sfx.i.click();
    try {
      final x = double.parse(a.text);
      final y = double.parse(b.text);
      double r;
      switch (op) {
        case '+':
          r = x + y;
          break;
        case '-':
          r = x - y;
          break;
        case 'x':
          r = x * y;
          break;
        case '/':
          r = y == 0 ? double.nan : x / y;
          break;
        case '%':
          r = x * y / 100;
          break;
        default:
          r = 0;
      }
      out = 'Hasil: $r';
    } catch (_) {
      out = 'Masukkan dua angka yang valid.';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'KALKULATOR',
        child: ListView(children: [
          TermField(controller: a, hint: 'Angka 1', type: TextInputType.number),
          const SizedBox(height: 8),
          TermField(controller: b, hint: 'Angka 2', type: TextInputType.number),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final op in ['+', '-', 'x', '/', '%'])
              SizedBox(
                  width: 60, child: TermButton(label: op, onTap: () => _calc(op))),
          ]),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _UnitScreen extends StatefulWidget {
  const _UnitScreen();
  @override
  State<_UnitScreen> createState() => _UnitScreenState();
}

class _UnitScreenState extends State<_UnitScreen> {
  final input = TextEditingController();
  String mode = 'km_mi';
  String out = '';

  void _conv() {
    Sfx.i.click();
    try {
      final v = double.parse(input.text);
      double r;
      String label;
      switch (mode) {
        case 'km_mi':
          r = v * 0.621371;
          label = 'km -> mil';
          break;
        case 'kg_lb':
          r = v * 2.20462;
          label = 'kg -> lb';
          break;
        case 'c_f':
          r = v * 9 / 5 + 32;
          label = 'Celsius -> Fahrenheit';
          break;
        default:
          r = v;
          label = '';
      }
      out = '$label: ${r.toStringAsFixed(2)}';
    } catch (_) {
      out = 'Masukkan angka yang valid.';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'KONVERTER SATUAN',
        child: ListView(children: [
          DropdownButton<String>(
            value: mode,
            dropdownColor: TermPalette.panel,
            style: termText(13, TermPalette.text),
            items: const [
              DropdownMenuItem(value: 'km_mi', child: Text('Kilometer -> Mil')),
              DropdownMenuItem(value: 'kg_lb', child: Text('Kilogram -> Pon')),
              DropdownMenuItem(value: 'c_f', child: Text('Celsius -> Fahrenheit')),
            ],
            onChanged: (v) => setState(() => mode = v ?? mode),
          ),
          const SizedBox(height: 10),
          TermField(controller: input, hint: 'Masukkan nilai...', type: TextInputType.number),
          const SizedBox(height: 10),
          TermButton(label: 'KONVERSI', onTap: _conv),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _TimerScreen extends StatefulWidget {
  const _TimerScreen();
  @override
  State<_TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<_TimerScreen> {
  int seconds = 0;
  Timer? t;
  bool running = false;

  void _toggle() {
    Sfx.i.click();
    if (running) {
      t?.cancel();
      setState(() => running = false);
    } else {
      setState(() => running = true);
      t = Timer.periodic(const Duration(seconds: 1), (_) {
        setState(() => seconds++);
      });
    }
  }

  void _reset() {
    Sfx.i.click();
    t?.cancel();
    setState(() {
      running = false;
      seconds = 0;
    });
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return TermScaffold(
      title: 'STOPWATCH',
      child: Column(children: [
        const SizedBox(height: 40),
        Text('$m:$s', style: termText(48, TermPalette.accent)),
        const SizedBox(height: 30),
        Row(children: [
          Expanded(child: TermButton(label: running ? 'STOP' : 'START', onTap: _toggle)),
          const SizedBox(width: 10),
          Expanded(child: TermButton(label: 'RESET', onTap: _reset)),
        ]),
      ]),
    );
  }
}
