import 'dart:async';
import 'package:noise_meter/noise_meter.dart';
import 'package:permission_handler/permission_handler.dart';

/// Mendeteksi tiupan ke mikrofon lewat lonjakan desibel yang singkat.
/// Fitur ini sepenuhnya opsional: jika izin ditolak atau mic tidak
/// tersedia, [start] gagal secara diam dan tidak memengaruhi bagian
/// lain aplikasi.
class MicBlowDetector {
  final void Function() onBlow;
  MicBlowDetector(this.onBlow);

  NoiseMeter? _meter;
  StreamSubscription<NoiseReading>? _sub;
  int _lastBlow = 0;
  bool running = false;

  Future<bool> start() async {
    try {
      final status = await Permission.microphone.request();
      if (!status.isGranted) return false;
      _meter = NoiseMeter();
      _sub = _meter!.noise.listen((reading) {
        final now = DateTime.now().millisecondsSinceEpoch;
        // Tiupan dekat mic biasanya menghasilkan lonjakan dB tinggi.
        if (reading.maxDecibel > 75 && now - _lastBlow > 1800) {
          _lastBlow = now;
          onBlow();
        }
      }, onError: (_) {});
      running = true;
      return true;
    } catch (_) {
      running = false;
      return false;
    }
  }

  void stop() {
    try {
      _sub?.cancel();
    } catch (_) {}
    running = false;
  }
}
