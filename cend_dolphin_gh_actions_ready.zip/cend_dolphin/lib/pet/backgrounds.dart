import 'dart:math';
import 'package:flutter/material.dart';
import 'package:cend_dolphin/pet/pet_model.dart';

/// Background animasi ringan (CustomPainter + 1 AnimationController).
/// Dirancang hemat: tidak membuat banyak widget, semua digambar via painter.
class PetBackground extends StatefulWidget {
  final Background bg;
  const PetBackground({super.key, required this.bg});
  @override
  State<PetBackground> createState() => _PetBackgroundState();
}

class _PetBackgroundState extends State<PetBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController c =
      AnimationController(vsync: this, duration: const Duration(seconds: 12))
        ..repeat();

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: c,
        builder: (_, __) => CustomPaint(
          painter: _BgPainter(widget.bg, c.value),
          size: Size.infinite,
        ),
      );
}

class _BgPainter extends CustomPainter {
  final Background bg;
  final double t; // 0..1 loop
  _BgPainter(this.bg, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    switch (bg) {
      case Background.pantai:
        _pantai(canvas, size);
        break;
      case Background.rumah:
        _rumah(canvas, size);
        break;
      case Background.hujan:
        _hujan(canvas, size);
        break;
      case Background.taman:
        _taman(canvas, size);
        break;
      case Background.hutan:
        _hutan(canvas, size);
        break;
      case Background.luarAngkasa:
        _luarAngkasa(canvas, size);
        break;
    }
  }

  void _sky(Canvas c, Size s, List<Color> colors) {
    final p = Paint()
      ..shader = LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: colors)
          .createShader(Rect.fromLTWH(0, 0, s.width, s.height));
    c.drawRect(Rect.fromLTWH(0, 0, s.width, s.height), p);
  }

  void _pantai(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFFBFE3F2), Color(0xFFE9F6EF)]);
    final sunY = s.height * 0.18;
    c.drawCircle(Offset(s.width * 0.78, sunY), 26,
        Paint()..color = const Color(0xFFFCE1A0));
    // awan bergerak pelan
    for (int i = 0; i < 3; i++) {
      final x = ((t + i * 0.33) % 1.0) * (s.width + 100) - 50;
      _cloud(c, Offset(x, s.height * (0.12 + i * 0.07)), 0.7 + i * 0.1);
    }
    // laut
    c.drawRect(Rect.fromLTWH(0, s.height * 0.62, s.width, s.height * 0.18),
        Paint()..color = const Color(0xFF8FCBDE));
    // ombak
    final wave = Paint()..color = const Color(0xFFBFE3F2);
    final path = Path()..moveTo(0, s.height * 0.62);
    for (double x = 0; x <= s.width; x += 20) {
      final y = s.height * 0.62 +
          sin((x / 40) + t * 2 * pi) * 4;
      path.lineTo(x, y);
    }
    path.lineTo(s.width, s.height * 0.6);
    path.lineTo(0, s.height * 0.6);
    path.close();
    c.drawPath(path, wave);
    // pasir
    c.drawRect(Rect.fromLTWH(0, s.height * 0.8, s.width, s.height * 0.2),
        Paint()..color = const Color(0xFFF2E3C2));
    // pohon kelapa (goyang)
    final sway = sin(t * 2 * pi) * 6;
    final trunk = Paint()..color = const Color(0xFF9B7653);
    c.drawRect(
        Rect.fromLTWH(s.width * 0.08, s.height * 0.55, 10, s.height * 0.3),
        trunk);
    final leaf = Paint()..color = const Color(0xFF6FA66B);
    for (int i = 0; i < 4; i++) {
      final ang = (i * pi / 2.2) + sway * 0.02;
      final cx = s.width * 0.08 + 5;
      final cy = s.height * 0.55;
      c.drawOval(
          Rect.fromCenter(
              center: Offset(cx + cos(ang) * 28, cy + sin(ang) * 14 - 10),
              width: 40,
              height: 16),
          leaf);
    }
  }

  void _cloud(Canvas c, Offset o, double scale) {
    final p = Paint()..color = Colors.white.withOpacity(0.9);
    c.drawCircle(o, 14 * scale, p);
    c.drawCircle(o + Offset(14 * scale, 2), 10 * scale, p);
    c.drawCircle(o + Offset(-14 * scale, 2), 10 * scale, p);
  }

  void _rumah(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFFF3E6D6), Color(0xFFEAD9C4)]);
    // dinding kayu
    c.drawRect(Rect.fromLTWH(0, 0, s.width, s.height),
        Paint()..color = const Color(0xFFEAD9C4));
    final plank = Paint()..color = const Color(0xFFDDC6A6);
    for (double y = 20; y < s.height; y += 36) {
      c.drawRect(Rect.fromLTWH(0, y, s.width, 2), plank);
    }
    // jendela
    final win = Paint()..color = const Color(0xFFBFE3F2);
    final winRect = Rect.fromLTWH(s.width * 0.1, s.height * 0.12, 70, 70);
    c.drawRect(winRect, win);
    c.drawRect(winRect, Paint()
      ..color = const Color(0xFF9B7653)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4);
    // lampu berkedip lembut
    final flick = (sin(t * 2 * pi * 3) + 1) / 2;
    c.drawCircle(Offset(s.width * 0.85, s.height * 0.15), 10,
        Paint()..color = Color.lerp(const Color(0xFFFFE9A8), const Color(0xFFFFF6D9), flick)!);
    // tanaman goyang
    final sway = sin(t * 2 * pi) * 4;
    final pot = Paint()..color = const Color(0xFFC97B4A);
    c.drawRect(Rect.fromLTWH(s.width * 0.75, s.height * 0.78, 30, 18), pot);
    final leaf = Paint()..color = const Color(0xFF7CAE7A);
    for (int i = 0; i < 3; i++) {
      c.drawOval(
          Rect.fromCenter(
              center: Offset(s.width * 0.75 + 15 + sway + i * 4,
                  s.height * 0.78 - 8 - i * 6),
              width: 16,
              height: 22),
          leaf);
    }
  }

  void _hujan(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFF5C6B7A), Color(0xFF8694A1)]);
    // gedung
    final b1 = Paint()..color = const Color(0xFF4A5663);
    c.drawRect(Rect.fromLTWH(0, s.height * 0.45, s.width * 0.3, s.height * 0.55), b1);
    c.drawRect(Rect.fromLTWH(s.width * 0.7, s.height * 0.35, s.width * 0.3, s.height * 0.65), b1);
    // hujan
    final rain = Paint()
      ..color = Colors.white.withOpacity(0.5)
      ..strokeWidth = 2;
    final rnd = Random(1);
    for (int i = 0; i < 40; i++) {
      final baseX = rnd.nextDouble() * s.width;
      final x = (baseX + t * 60) % s.width;
      final y = ((rnd.nextDouble() + t * 3 + i * 0.1) % 1.0) * s.height;
      c.drawLine(Offset(x, y), Offset(x - 4, y + 14), rain);
    }
    // genangan berkilau
    c.drawOval(
        Rect.fromCenter(
            center: Offset(s.width * 0.5, s.height * 0.92), width: 80, height: 10),
        Paint()..color = const Color(0xFF9FB4C4).withOpacity(0.6));
  }

  void _taman(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFFDFF3E3), Color(0xFFF3FBE9)]);
    c.drawRect(Rect.fromLTWH(0, s.height * 0.65, s.width, s.height * 0.35),
        Paint()..color = const Color(0xFFBFE0C4));
    final rnd = Random(2);
    final colors = [
      const Color(0xFFF4B6C2),
      const Color(0xFFFCE1A0),
      const Color(0xFFAFCBE8),
    ];
    for (int i = 0; i < 8; i++) {
      final x = (i / 8) * s.width + 20;
      final sway = sin(t * 2 * pi + i) * 4;
      c.drawCircle(Offset(x + sway, s.height * 0.78), 6,
          Paint()..color = colors[i % colors.length]);
      c.drawRect(Rect.fromLTWH(x + sway - 1, s.height * 0.8, 2, 14),
          Paint()..color = const Color(0xFF6FA66B));
    }
    // kupu-kupu terbang
    final bx = (t * s.width * 1.4) % (s.width + 40) - 20;
    final by = s.height * 0.4 + sin(t * 2 * pi * 4) * 20;
    final wing = Paint()..color = const Color(0xFFF4B6C2);
    c.drawOval(Rect.fromCenter(center: Offset(bx - 4, by), width: 10, height: 8), wing);
    c.drawOval(Rect.fromCenter(center: Offset(bx + 4, by), width: 10, height: 8), wing);
  }

  void _hutan(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFFCFE3C9), Color(0xFFE9F3E3)]);
    final trunk = Paint()..color = const Color(0xFF7A5C3E);
    final leaf = Paint()..color = const Color(0xFF5E9A5B);
    for (int i = 0; i < 3; i++) {
      final x = s.width * (0.2 + i * 0.3);
      c.drawRect(Rect.fromLTWH(x, s.height * 0.4, 14, s.height * 0.5), trunk);
      c.drawCircle(Offset(x + 7, s.height * 0.35), 36, leaf);
    }
    // daun jatuh
    final rnd = Random(3);
    for (int i = 0; i < 10; i++) {
      final fx = rnd.nextDouble() * s.width;
      final fy = ((rnd.nextDouble() + t + i * 0.1) % 1.0) * s.height;
      c.drawCircle(Offset(fx + sin(fy / 20) * 8, fy), 3,
          Paint()..color = const Color(0xFFD9A441));
    }
    // kunang-kunang
    final gx = s.width * 0.5 + sin(t * 2 * pi * 2) * 60;
    final gy = s.height * 0.6 + cos(t * 2 * pi * 2) * 20;
    c.drawCircle(Offset(gx, gy), 3,
        Paint()..color = const Color(0xFFFCE87A).withOpacity(0.5 + 0.5 * sin(t * 10)));
  }

  void _luarAngkasa(Canvas c, Size s) {
    _sky(c, s, const [Color(0xFF1B1830), Color(0xFF342B57)]);
    final rnd = Random(4);
    for (int i = 0; i < 40; i++) {
      final x = rnd.nextDouble() * s.width;
      final y = rnd.nextDouble() * s.height;
      final tw = (sin(t * 2 * pi * 2 + i) + 1) / 2;
      c.drawCircle(Offset(x, y), 1.2,
          Paint()..color = Colors.white.withOpacity(0.3 + tw * 0.7));
    }
    // bulan
    c.drawCircle(Offset(s.width * 0.2, s.height * 0.18), 20,
        Paint()..color = const Color(0xFFEDE3F5));
    // planet berputar
    final px = s.width * 0.75;
    final py = s.height * 0.3;
    c.drawCircle(Offset(px, py), 18, Paint()..color = const Color(0xFFE59A6B));
    c.save();
    c.translate(px, py);
    c.rotate(t * 2 * pi);
    c.drawOval(Rect.fromCenter(center: Offset.zero, width: 44, height: 10),
        Paint()
          ..color = const Color(0xFFC9BCE0)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3);
    c.restore();
    // asteroid lewat
    final ax = (t * s.width * 1.2) % (s.width + 40) - 20;
    c.drawCircle(Offset(ax, s.height * 0.6), 5,
        Paint()..color = const Color(0xFF8A7F9E));
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) =>
      old.bg != bg || old.t != t;
}
