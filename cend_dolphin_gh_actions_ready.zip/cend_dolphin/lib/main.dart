import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';
import 'package:cend_dolphin/pet/pet_model.dart';
import 'package:cend_dolphin/pet/pet_screen.dart';
import 'package:cend_dolphin/pet/select_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CendDolphinApp());
}

class CendDolphinApp extends StatelessWidget {
  const CendDolphinApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Cend Dolphin',
        theme: ThemeData(
          scaffoldBackgroundColor: PastelPalette.cream,
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: PastelPalette.orange),
        ),
        home: const SplashScreen(),
      );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Sfx.i.loadPrefs();
    Sfx.i.splash();
    final active = await PetStore.loadActive();
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    if (active != null) {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => PetScreen(state: active)));
    } else {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const SelectPetScreen()));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: PastelPalette.cream,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('CEND DOLPHIN',
                style: roundedText(24, PastelPalette.brown, w: FontWeight.w800)),
            const SizedBox(height: 12),
            const CircularProgressIndicator(color: PastelPalette.orange),
          ]),
        ),
      );
}
