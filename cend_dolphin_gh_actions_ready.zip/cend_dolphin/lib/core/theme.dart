import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palet pastel lembut untuk layar Pet.
class PastelPalette {
  static const cream = Color(0xFFFBF2E9);
  static const creamDark = Color(0xFFF3E6D6);
  static const brown = Color(0xFF8A6A56);
  static const brownSoft = Color(0xFFB79C87);
  static const pink = Color(0xFFF4B6C2);
  static const blue = Color(0xFFAFCBE8);
  static const green = Color(0xFFBFE0C4);
  static const orange = Color(0xFFF2B383);
  static const purple = Color(0xFFC9BCE0);
  static const white = Color(0xFFFFFFFF);
}

/// Palet gelap terminal untuk layar Tools.
class TermPalette {
  static const bg = Color(0xFF121212);
  static const panel = Color(0xFF1C1C1C);
  static const accent = Color(0xFFFF8A2A);
  static const text = Color(0xFFE8E8E8);
  static const dim = Color(0xFF8A8A8A);
  static const danger = Color(0xFFFF5C5C);
  static const ok = Color(0xFF6BD08A);
}

TextStyle roundedText(double size, Color c, {FontWeight w = FontWeight.w600}) =>
    GoogleFonts.baloo2(fontSize: size, color: c, fontWeight: w, height: 1.3);

TextStyle termText(double size, Color c) =>
    GoogleFonts.robotoMono(fontSize: size, color: c, height: 1.4);

const kPetBg = PastelPalette.cream;
